package ch.fhnw.oop2.progtest1;

import java.util.*;
import java.util.stream.Collectors;

public class CollectionTasks {

    /**
     * Fügt die beiden Strings first und second beide je am Anfang und am Ende
     * der gegebenen Liste ein.
     * 
     * Beispiel: Für eine Liste ["a", "b", "c"] und die Strings "x" und "y",
     * sieht die Liste am Ende so aus: ["x", "y", "a", "b", "c", "x", "y"]
     */
    public static void listInsertStartEnd(List<String> list, String first,
            String second) {
        list.add(0, first);
        list.add(1, second);
        list.add(first);
        list.add(second);
    }

    /**
     * Berechnet die Summe aller Zahlen in numbers und gibt sie zurück. Falls
     * numbers gleich null ist, soll -1 zurückgegeben werden.
     */
    public static int setSum(Set<Integer> numbers) {
        // TODO
        if (numbers == null) {
            return -1;
        }

        return numbers.stream().mapToInt(number -> number).sum();
    }

    /**
     * Entfernt alle Einträge aus der gegebenen Map, bei welchen der Schlüssel
     * negativ ist.
     * 
     * Achtung: Falls es nichts zu entfernen gibt, soll die Methode auch mit
     * unveränderlichen Maps funktionieren.
     */
    public static void mapRemoveNegativeKeys(Map<Integer, String> map) {
        map.entrySet().removeIf(entry -> entry.getKey() < 0);
    }

    /**
     * Ersetzt jeden String s in der gegebenen Liste mit dem Wert, der in der
     * gegebenen Map mit diesem String assoziiert ist. Falls ein String keinen
     * assoziierten Wert in der Map hat, wird er entfernt.
     * 
     * Beispiel: Für eine Liste ["stupid", "idiot", "why", "did", "you"] und
     * einer Map {"stupid" = "unsmart", "idiot" = "fool"} ist das Resultat
     * ["unsmart", "fool"].
     */
    public static void listReplace(List<String> list, Map<String, String> map) {
        List<String> result = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) {
            String entry = list.get(i);
            if (map.get(entry) == null) {
                list.remove(i);
                i--;
            } else {
                list.remove(i);
                i--;
                result.add(entry);
            }
        }
        list.clear();
        list.addAll(result);
    }

    /**
     * Gibt den grösseren der beiden Werte zurück, die mit den beiden Strings
     * first und second in der gegebenen Map assoziiert sind. Falls einer der
     * beiden Strings nicht in der Map vorkommt, wird der Wert für den anderen
     * zurückgegeben; falls beide nicht vorkommen, wird null zurückgegegen.
     */
    public static Integer mapMax(Map<String, Integer> map, String first,
            String second) {
        Integer firstEntry = map.get(first);
        Integer secondEntry = map.get(second);

        if (firstEntry == null && secondEntry == null) {
            return null;
        } else if (secondEntry == null) {
            return firstEntry;
        } else if (firstEntry == null) {
            return secondEntry;
        }

        if (firstEntry > secondEntry) {
            return firstEntry;
        } else {
            return secondEntry;
        }
    }

    /**
     * Gibt ein neues Set zurück, welche alle Elemente enthält, die sich in
     * first oder in second befinden, aber nicht in beiden.
     * 
     * Achtung: Die übergebenen Sets first und second dürfen nicht verändert
     * werden.
     */
    public static Set<String> setSymmetricDiff(Set<String> first,
            Set<String> second) {
        // TODO
        return null;
    }

    /**
     * Fügt den gegebenen Wert in die gegebene, aufsteigend sortierte Liste ein,
     * so dass die Liste weiterhin sortiert bleibt. Falls die Liste zu Beginn
     * unsortiert ist, ist das Verhalten undefiniert (d.h. Sie müssen sich zu
     * diesem Fall keine Gedanken machen).
     * 
     * Beispiel: Für eine Liste [1, 4, 5, 8] und den Wert 7 sieht die Liste am
     * Ende so aus: [1, 4, 5, 7, 8].
     * 
     * Hinweis: Die Effizienz der Lösung ist nicht relevant.
     */
    public static void listInsertSorted(List<Integer> list, int value) {
        // TODO
    }

    /**
     * Entfernt aus der Map first alle Einträge, welche einen Wert haben, der
     * nicht als Schlüssel in der Map second vorkommt.
     */
    public static void mapRemoveNonKeys(Map<String, Integer> first,
            Map<Integer, Double> second) {
        // TODO
    }
}
